create database insta;
use insta;
create table users(id int , name varchar(20));
insert into users values(1,'Darshan'),(2,'niki');
